<!DOCTYPE  html>
<html lang="ro">
<head>
	<meta name="robots" content="noindex, nofollow">
</head>
<body>
	<?php 

		require_once( 'helpdeskoffice/classes/Gameplay.php');
		require_once( 'helpdeskoffice/classes/Oderus.php');
		require_once( 'helpdeskoffice/classes/Beast.php');

		$oderus 		= new Oderus();
		$beast_one		= new Beast();
	 	$beast_two		= new Beast();

		$game = new Gameplay( $beast_one, $beast_two, $oderus );	

	?>

</body>
</html>