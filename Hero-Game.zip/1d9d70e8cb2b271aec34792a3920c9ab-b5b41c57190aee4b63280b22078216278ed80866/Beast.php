<?php

	Class Beast extends AbstractCharacter
	{
		
		protected $strength;
		protected $defense;
		protected $speed;
		protected $luck;
		protected $health;
		protected $name;

		
		public function __construct()
		{
			$this->specialAttack 	= false;
			$this->sepcialDefend 	= false;
			$this->health 		= rand(60, 90);
			$this->strength 	= rand(60, 90);
			$this->defense		= rand(40, 60);
			$this->speed		= rand(40, 60);
			$this->luck			= rand(25, 40);
			$this->name			= "I'm a Beast from the wood's with no name";
			
						


		}

}
